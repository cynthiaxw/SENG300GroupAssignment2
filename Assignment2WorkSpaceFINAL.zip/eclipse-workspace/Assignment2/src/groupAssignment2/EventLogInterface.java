package groupAssignment2;
/**
 *For Testing
 */
public interface EventLogInterface {

	public void writeToLog(String s);
	
	public void timeStamp();
}
