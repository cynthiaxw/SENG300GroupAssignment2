
GROUP 5

Chandler Bullock	
Trent Trevor David Johnston	
David Keizer	
Mahsa Lotfi Gaskarimahalleh	
Hao Rao	
Xi Wang	

Note that the zip folder contains both the JUNIT test suite as well as the vending logic classes.

The software is stable on VendingMachine 2.1, but due to severe time constraints, the documentation does not recognize this.

Thanks, 

Group 5