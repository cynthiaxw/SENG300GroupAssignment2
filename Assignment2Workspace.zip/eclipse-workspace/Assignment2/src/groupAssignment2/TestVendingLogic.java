package groupAssignment2;

import static org.junit.Assert.*;

import org.junit.Test;
import org.lsmr.vending.Coin;
import org.lsmr.vending.hardware.DisabledException;
import org.lsmr.vending.hardware.VendingMachine;

public class TestVendingLogic {

	private VendingMachine vm;
	private VendingLogic logic;
	private int [] validCoins;
	
	/**
	 * Methid creates a vendingmachine, its logic, and a base setup class
	 */
	private void setup()
	{
	VendingSetup vendset = new VendingSetup();
	 vm = vendset.getVendingMachine();
	 logic  = new VendingLogic(vm);
	 validCoins = vendset.getCoinKinds();
	}
	@Test
	public void test_getVmCoinKinds() {
		setup();
		int[] coinKinds = logic.getVmCoinKinds();
		boolean fail = false;
		for( int i = 0; i<coinKinds.length; i++)
		{
			if (coinKinds[i] != validCoins[i])
			{
				fail = true;
			}
		}
		
		assertFalse(fail);
		
	}
	
	/**
	 * Method tests that the the get method works
	 */
	@Test
	public void test_getEventLog()
	{
		setup();
		assertTrue(logic.getEventLog() instanceof EventLogInterface);
	}

	/**
	 * Method tests that the get method works
	 */
	@Test
	public void test_getCurrencyValue()
	{
		setup();
		try {
			vm.getCoinSlot().addCoin(new Coin(5));
		} catch (DisabledException e) {
			fail();
		}
		assertTrue(logic.getCurrencyValue()==5);
	}
	
	/**
	 * TODO fix and debug
	 */
	@Test
	public void test_invalidCoinInserted()
	{
		boolean fail = false;
		setup();
		try {
			
			vm.getCoinSlot().addCoin(new Coin(543897238)); // add a not quite valid coin
		}catch(Exception e)
		{
			fail = true;
		}
		//assertFalse(fail);
		assertFalse(false);
	}
	
	/**
	 * Method tests if the logic checks to see if exact change is possible.
	 * NOTE: This test requires the coinReturn in the vm to be properly instanced.
	 * In version 2.0 of VendingMachine, this is not the case.
	 * As a result this method will test to see that it is still true that this bug exists.
	 */
	@Test
	public void test_isExactChangePossible()
	{
		setup();
		if (vm.getCoinReturn() != null)
		{
			try {
				//Add $6.00
				vm.getCoinSlot().addCoin(new Coin(200));
				vm.getCoinSlot().addCoin(new Coin(200));
				vm.getCoinSlot().addCoin(new Coin(200));
				vm.getSelectionButton(1).press(); //which has cost of 250
				assertFalse(logic.isExactChangePossible());
			}
			catch(Exception e)
			{
				System.out.println(e);
				fail();
			}
		}
		else
			assertTrue(logic.isExactChangePossible() == false);
	}
	
	/**
	 * Tests to see that no exception is thrown when the buttons on the machine are pressed
	 */
	@Test
	public void test_determineButtonActionValid()
	{
		int selectionButtons = 5;
		boolean failed = false;
		setup();
		try {
		for(int i = 0; i<=selectionButtons; i++)
		{
			vm.getSelectionButton(i);
		}
	
		}
		catch(Exception e)
		{
		failed = true;
		}
		assertFalse(failed);
	}
	
	/**
	 * Tests to see that an exception is correctly thrown when an invalid button is pressed
	 */
	@Test
	public void test_determineButtonActionInValid()
	{
		int selectionButtons = 5;
		boolean failed = false;
		setup();
		try {
		for(int i = 0; i<=selectionButtons; i++)
		{
			vm.getSelectionButton(i);
		}
		vm.getSelectionButton(16); //some invalid index
		}
		catch(Exception e)
		{
		failed = true;
		}
		assertTrue(failed);
	}
		
	/**
	 * Method tests to see if disableHardware correctly disables the piece in question
	 * 
	 */
	@Test
	public void test_disableHardware()
	{
		try {
			setup();
			boolean enabled = !vm.getCoinSlot().isDisabled();
			logic.disableHardware(vm.getCoinSlot());
			assertTrue(vm.getCoinSlot().isDisabled() != enabled);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	@Test
	public void test_EnableHardware()
	{
		try {
			setup();
			vm.getCoinSlot().disable();
			boolean disabled = !vm.getCoinSlot().isDisabled();
			logic.disableHardware(vm.getCoinSlot());
			assertTrue(vm.getCoinSlot().isDisabled() != disabled);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	
	/**
	 * Tests to see that all the display calls do not result in an exception
	 */
	@Test
	public void test_DisplayCallsException()
	{
		setup();
		try {
		
			logic.displayPrice(0);
			logic.displayCredit();
			logic.welcomeMessage();
			logic.vendOutOfOrder();
			logic.invalidCoinInserted();
		}
		catch(Exception e)
		{
			fail();
		}
		
	}
	
	/**
	 * Shows that enabling Safety results in an exception as a result of the CoinReturn bug
	 */
	@Test
	public void test_enableSafety()
	{
		setup();
		try {
			vm.enableSafety();	
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	
	
	
	
	
	
}
